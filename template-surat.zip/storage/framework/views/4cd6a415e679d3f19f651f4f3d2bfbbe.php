<time
    <?php echo e($attributes->class(['fi-no-notification-date text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</time>
<?php /**PATH C:\Users\zedla\template-surat\template-surat\vendor\filament\notifications\resources\views\components\date.blade.php ENDPATH**/ ?>