<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.kelas-resource.pages.create-kelas' => 'App\\Filament\\Resources\\KelasResource\\Pages\\CreateKelas',
    'app.filament.resources.kelas-resource.pages.edit-kelas' => 'App\\Filament\\Resources\\KelasResource\\Pages\\EditKelas',
    'app.filament.resources.kelas-resource.pages.list-kelas' => 'App\\Filament\\Resources\\KelasResource\\Pages\\ListKelas',
    'app.filament.resources.kelas-resource.pages.view-kelas' => 'App\\Filament\\Resources\\KelasResource\\Pages\\ViewKelas',
    'app.filament.resources.kelas-resource.relation-managers.siswas-relation-manager' => 'App\\Filament\\Resources\\KelasResource\\RelationManagers\\SiswasRelationManager',
    'app.filament.resources.siswa-resource.pages.create-siswa' => 'App\\Filament\\Resources\\SiswaResource\\Pages\\CreateSiswa',
    'app.filament.resources.siswa-resource.pages.edit-siswa' => 'App\\Filament\\Resources\\SiswaResource\\Pages\\EditSiswa',
    'app.filament.resources.siswa-resource.pages.list-siswas' => 'App\\Filament\\Resources\\SiswaResource\\Pages\\ListSiswas',
    'app.filament.resources.siswa-resource.pages.view-siswa' => 'App\\Filament\\Resources\\SiswaResource\\Pages\\ViewSiswa',
    'app.filament.resources.tahun-pelajaran-resource.pages.create-tahun-pelajaran' => 'App\\Filament\\Resources\\TahunPelajaranResource\\Pages\\CreateTahunPelajaran',
    'app.filament.resources.tahun-pelajaran-resource.pages.edit-tahun-pelajaran' => 'App\\Filament\\Resources\\TahunPelajaranResource\\Pages\\EditTahunPelajaran',
    'app.filament.resources.tahun-pelajaran-resource.pages.list-tahun-pelajarans' => 'App\\Filament\\Resources\\TahunPelajaranResource\\Pages\\ListTahunPelajarans',
    'app.filament.resources.tahun-pelajaran-resource.pages.view-tahun-pelajaran' => 'App\\Filament\\Resources\\TahunPelajaranResource\\Pages\\ViewTahunPelajaran',
    'app.filament.resources.tahun-pelajaran-resource.relation-managers.kelas-relation-manager' => 'App\\Filament\\Resources\\TahunPelajaranResource\\RelationManagers\\KelasRelationManager',
    'app.filament.resources.tahun-pelajaran-resource.relation-managers.siswas-relation-manager' => 'App\\Filament\\Resources\\TahunPelajaranResource\\RelationManagers\\SiswasRelationManager',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'app.filament.resources.user-resource.pages.view-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\ViewUser',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'app.filament.widgets.siswa-overview' => 'App\\Filament\\Widgets\\SiswaOverview',
    'app.filament.widgets.siswa-per-tingkat-chart' => 'App\\Filament\\Widgets\\SiswaPerTingkatChart',
    'app.filament.widgets.tahun-pelajaran-chart' => 'App\\Filament\\Widgets\\TahunPelajaranChart',
    'app.filament.widgets.tingkat-overview' => 'App\\Filament\\Widgets\\TingkatOverview',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\Users\\zedla\\template-surat\\template-surat\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\Users\\zedla\\template-surat\\template-surat\\app\\Filament\\Resources\\KelasResource.php' => 'App\\Filament\\Resources\\KelasResource',
    'C:\\Users\\zedla\\template-surat\\template-surat\\app\\Filament\\Resources\\SiswaResource.php' => 'App\\Filament\\Resources\\SiswaResource',
    'C:\\Users\\zedla\\template-surat\\template-surat\\app\\Filament\\Resources\\TahunPelajaranResource.php' => 'App\\Filament\\Resources\\TahunPelajaranResource',
    'C:\\Users\\zedla\\template-surat\\template-surat\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\Users\\zedla\\template-surat\\template-surat\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\Users\\zedla\\template-surat\\template-surat\\app\\Filament\\Widgets\\SiswaOverview.php' => 'App\\Filament\\Widgets\\SiswaOverview',
    'C:\\Users\\zedla\\template-surat\\template-surat\\app\\Filament\\Widgets\\SiswaPerTingkatChart.php' => 'App\\Filament\\Widgets\\SiswaPerTingkatChart',
    'C:\\Users\\zedla\\template-surat\\template-surat\\app\\Filament\\Widgets\\TahunPelajaranChart.php' => 'App\\Filament\\Widgets\\TahunPelajaranChart',
    'C:\\Users\\zedla\\template-surat\\template-surat\\app\\Filament\\Widgets\\TingkatOverview.php' => 'App\\Filament\\Widgets\\TingkatOverview',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\Users\\zedla\\template-surat\\template-surat\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);